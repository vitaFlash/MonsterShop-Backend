package love.hazy.monster.services;

import love.hazy.monster.dtos.product.ProductRequest;
import love.hazy.monster.dtos.product.ProductResponse;
import love.hazy.monster.dtos.product.ProductMapper;
import love.hazy.monster.models.Product;
import love.hazy.monster.repositories.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductService {
    @Autowired
    private ProductRepository productRepo;

    @Autowired
    private ProductMapper mapper;

    public List<ProductResponse> getAll() {
        return productRepo.findAll()
                .stream()
                .map(mapper::toResponse)
                .collect(Collectors.toList());
    }

    public ProductResponse getById(Long id) {
        Product product = productRepo.findById(id).orElseThrow();
        return mapper.toResponse(product);
    }

    public ProductResponse save(ProductRequest request) {
        Product product = mapper.toEntity(request);
        return mapper.toResponse(productRepo.save(product));
    }

    public ProductResponse update(Long id, ProductRequest updated) {
        Product product = productRepo.findById(id).orElseThrow();

        product.setName(updated.name());
        product.setDescription(updated.description());
        product.setPrice(updated.price());
        product.setImageUrl(updated.imageUrl());
        product.setRating(updated.rating());
        product.setReviewCount(updated.reviewCount());
        product.setFeatured(updated.featured());

        return mapper.toResponse(productRepo.save(product));
    }

    public void delete(Long id) {
        productRepo.deleteById(id);
    }
}
