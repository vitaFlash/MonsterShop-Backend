package love.hazy.monster.controllers;

import love.hazy.monster.dtos.product.ProductRequest;
import love.hazy.monster.dtos.product.ProductResponse;
import love.hazy.monster.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    @Autowired
    private ProductService service;

    @GetMapping
    public List<ProductResponse> all() {
        return service.getAll();
    }

    @GetMapping("/{id}")
    public ProductResponse one(@PathVariable Long id) {
        return service.getById(id);
    }

    @PostMapping
    public ProductResponse create(@RequestBody ProductRequest request) {
        return service.save(request);
    }

    @PutMapping("/{id}")
    public ProductResponse update(@PathVariable Long id, @RequestBody ProductRequest request) {
        return service.update(id, request);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);


    }
}
