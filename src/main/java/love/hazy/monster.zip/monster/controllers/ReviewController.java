package love.hazy.monster.controllers;

import love.hazy.monster.dtos.review.ReviewRequest;
import love.hazy.monster.dtos.review.ReviewResponse;
import love.hazy.monster.services.ReviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/reviews")
public class ReviewController {

    @Autowired
    private ReviewService service;

    @GetMapping("/{productId}")
    public List<ReviewResponse> reviewsByProduct(@PathVariable Long productId) {
        return service.getByProductId(productId);
    }

    @PostMapping
    public ReviewResponse createReview(@RequestParam Long productId, @RequestBody ReviewRequest request) {
        return service.addReview(productId, request);
    }
}
