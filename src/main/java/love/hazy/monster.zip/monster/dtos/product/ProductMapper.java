package love.hazy.monster.dtos.product;

public class ProductMapper {
    public static ProductResponse toResponse(ProductRequest request) {
        return new ProductResponse(
                request.id(),
                request.name(),
                request.description(),
                request.price(),
                request.imageUrl(),
                request.rating(),
                request.reviewCount(),
                request.featured()
        );
    }

    public static ProductRequest toRequest(ProductResponse response) {
        return new ProductRequest(
                response.id(),
                response.name(),
                response.description(),
                response.price(),
                response.imageUrl(),
                response.rating(),
                response.reviewCount(),
                response.featured()
        );
    }
}
