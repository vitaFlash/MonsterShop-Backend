package love.hazy.monster.dtos.review;

public class ReviewMapper {
    public static ReviewResponse toResponse(ReviewRequest request) {
        return new ReviewResponse(
                request.id(),
                request.productId(),
                request.username(),
                request.body(),
                request.rating(),
                request.featured()
        );
    }

    public static ReviewRequest toRequest(ReviewResponse response) {
        return new ReviewRequest(
                response.id(),
                response.productId(),
                response.username(),
                response.body(),
                response.rating(),
                response.featured()
        );
    }
}
