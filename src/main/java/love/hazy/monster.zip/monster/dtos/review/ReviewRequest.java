package love.hazy.monster.dtos.review;

public record ReviewRequest(
        Long id,
        Long productId,
        String username,
        String body,
        double rating,
        boolean featured
) {
}
