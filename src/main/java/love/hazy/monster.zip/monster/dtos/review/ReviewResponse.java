package love.hazy.monster.dtos.review;

public record ReviewResponse(
        Long id,
        Long productId,
        String username,
        String body,
        double rating,
        boolean featured
) {
}
